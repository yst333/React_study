import React from 'react';
import FetchGet from './FetchGet';

const App = () => {
  return (
    <div>
      <h1>Start React 2023!</h1>
      <FetchGet />
    </div>
  );
};

export default App;