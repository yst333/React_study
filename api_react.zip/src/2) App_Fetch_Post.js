import React from 'react';
import FetchPost from './FetchPost';

const App = () => {
  return (
    <div>
      <h1>Start React 2023!</h1>
      <FetchPost />
    </div>
  );
};

export default App;