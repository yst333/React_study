import React from 'react';
import AxiosGet from './AxiosGet';

const App = () => {
  return (
    <div>
      <h1>Start React 2023!</h1>
      <AxiosGet />
    </div>
  );
};

export default App;