import React from 'react';
import AxiosPost from './AxiosPost';


const App = () => {
  return (
    <div>
      <h1>Start React 2023!</h1>
      <AxiosPost />
    </div>
  );
};

export default App;