import React from 'react';
import PromiseThen from './PromiseThen';


const App = () => {
  return (
    <div>
      <h1>Start React 2023!</h1>
      <PromiseThen />
    </div>
  );
};

export default App;