import React from 'react';
import PromiseCatch from './PromiseCatch';


const App = () => {
  return (
    <div>
      <h1>Start React 2023!</h1>
      <PromiseCatch />
    </div>
  );
};

export default App;