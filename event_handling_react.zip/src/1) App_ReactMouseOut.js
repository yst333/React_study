import React from 'react';
import ReactMouseOut from './ReactMouseOut';

const App = () => {
  return (
    <div>
      <h1>Start React 2023</h1>
      <ReactMouseOut />
    </div>
  );
};

export default App;