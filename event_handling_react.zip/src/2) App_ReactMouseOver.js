import React from 'react';
import ReactMouseOver from './ReactMouseOver';


const App = () => {
  return (
    <div>
      <h1>Start React 2023</h1>
      <ReactMouseOver />
    </div>
  );
};

export default App;