import React from 'react';
import ReactSubmit from './ReactSubmit';

const App = () => {
  return (
    <div>
      <h1>Start React 2023</h1>
      <ReactSubmit />
    </div>
  );
};

export default App;