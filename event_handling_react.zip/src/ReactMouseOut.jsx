// react 에서는 onMouseOut 이벤트도 camelCase 형식의 네이밍 형식을
// 사용합니다. onMouseOut 이벤트는 특정 tag 영역 안에 마우스 커서가
// 진입했다가 벗어날 때 발생합니다.

import React, { Component } from 'react';

class ReactMouseOut extends Component {
    // MouseOut이라는 함수를 선언하고 전달 받은 파라미터를 tag라는
    // 함수의 내부 변수에 넣어 사용합니다.
    MouseOut(tag){
        // tag 변수를 로그로 출력합니다.
        console.log('TAG : ' + tag);
    }    
    render() {
        return (
            <div>
            {/* div 태그 영역에 마우스 커서가 진입했다가 벗어날 경우
                MouseOut 함수를 호출합니다. 파라미터로 넘긴 div가
                본소스 로그로 출력됩니다.  */}
                <div onMouseOut={e => this.MouseOut("div")}>
                    <h3>DIV onMouseOut </h3>
                </div>    
            {/* input 태그 영역에 마우스 커서가 진입했다가 벗어날 경우
                MouseOut 함수를 호출합니다. 파라미터로 넘긴 input이
                본소스 로그로 출력됩니다.  */}    
                <input type='text' onMouseOut={e => this.MouseOut("input")} />
            {/* select 태그 영역에 마우스 커서가 진입했다가 벗어날 경우
                MouseOut 함수를 호출합니다. 파라미터로 넘긴 select가
                본소스 로그로 출력됩니다.  */}
                <select onMouseOut={e => this.MouseOut("select")}>
                    <option value={"react"}>react</option>
                    <option value={"2023"}>2023</option>
                </select>
            </div>
        );
    }
}

export default ReactMouseOut;