// react에서는 onSubmit 이벤트도 camelCase 형식의 네이밍을 사용합니다.
// onSubmit 이벤트는 form 태그에 사용합니다. form 태그 안에 있는
// type이 submit인 input 태그를 클릭하거나 input 태그에 커서를 놓고
// Enter키를 누르면 onSubmit 이벤트가 발생합니다.

import React, { Component } from 'react';

class ReactSubmit extends Component {

    Submit(e){
        var inputValue = document.getElementById("inputId").value;
        console.log("inputValue : " + inputValue);
        e.preventDefault();
    }
    render() {
        return (
            <form onSubmit={this.Submit}>
                <input type='text' name='inputName' id='inputId' />
                <input type='submit' value="Submit" />
            </form>
        );
    }
}

export default ReactSubmit;