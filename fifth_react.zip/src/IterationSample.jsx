// rsc + Ctrl + Spacebar - 함수형식 자동 생성
// rcc + Ctrl + Spacebar - 클래스형식 자동 생성
import React from 'react';

const IterationSample = () => {
    const names = ['눈사람', '얼음', '눈', '바람']
    const nameList = names.map((names, index => <li key={index}>{names}</li>));   
    return (
        <div>
            <ul>{nameList}</ul>
        </div>
    );
};

export default IterationSample;