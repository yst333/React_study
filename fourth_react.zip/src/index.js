import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

// 자식컴포넌트 => componentDidMount 두번 호출,
// 부모컴포넌트 => componentDidMount 두번 호출되는 문제 해결을 위하여 
// index.js 파일에 있는 <React.StrictMode> 태그를 주석 처리해 줍니다.
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  // <React.StrictMode>
    <App />
  // </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
