import React, {useState, useEffect} from 'react';
import logo from './logo.svg';
import './App.css';

function App() {

  const[message, setMessage] = useState("");

  useEffect(() => {
    fetch('/api/hello')
    .then(response => response.text())
    .then(message => {
      setMessage(message);
    });
    // useEffect에서 설정한 함수를 컴포넌가 화면에 맨 처음 렌더링될
    // 때만 실행하고, 업데이트될 때는 실행하지 않으려면 함수의 두번째
    // 파라미터로 비어 있는 배열을 넣어주면 됩니다.    
  },[]);

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <h1 className='App-title'>{message}</h1>
      </header>
    </div>
  );
}

export default App;
