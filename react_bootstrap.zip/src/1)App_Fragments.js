import React, { Fragment } from 'react';
import Fragments from './Fragments';

const App = () => {
  return (
    <div>
      <h1>Start React 2023</h1>
      <p>Fragments 적용하기</p>
      <Fragments />
    </div> 
  );
};

export default App;