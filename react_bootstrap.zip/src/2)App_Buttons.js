import React, { Fragment } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import ReactstrapButtons from '.ReactstrapButtons';

const App = () => {
  return (
    <div>
      <h1>Start React 2023</h1>
      <p>Fragments 적용하기</p>
      <ReactstrapButtons />
    </div> 
  );
};

export default App;