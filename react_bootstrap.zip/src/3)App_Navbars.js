import React, { Fragment } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import Navbars from './Navbars';

const App = () => {
  return (
    <div>
        <Navbars />
    </div> 
  );
};

export default App;