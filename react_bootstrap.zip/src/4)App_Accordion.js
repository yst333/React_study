import React, { Fragment } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import AccordionComponents from './AccordionComponents';

const App = () => {
  return (
    <div>
        <AccordionComponents />
    </div> 
  );
};

export default App;