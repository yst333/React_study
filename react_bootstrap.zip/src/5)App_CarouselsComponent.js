import React, { Fragment } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import CarouselsComponent from './CarouselsComponent';


const App = () => {
  return (
    <div>
        <CarouselsComponent />
    </div> 
  );
};

export default App;