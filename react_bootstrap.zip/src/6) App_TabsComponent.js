import React, { Fragment } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import TabsComponent from './TabsComponent';


const App = () => {
  return (
    <div>
        <TabsComponent />
    </div> 
  );
};

export default App;