import React, { Fragment } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import ModalsComponent from './ModalsComponents';


const App = () => {
  return (
    <div>
        <ModalsComponent />
    </div> 
  );
};

export default App;