import React, { Component } from 'react';


class Fragments extends Component {
    render() {
        return (
            <div>
                <p>p Tag입니다</p>
                <span>SPAN TAG입니다</span>
            </div>
        );
    }
}

export default Fragments;