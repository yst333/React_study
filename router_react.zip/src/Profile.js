import React from 'react';

const data = {
    star:{
        name : '장나라',
        descrpition: '리액트를 시작하는 개발자'
    },
    middle: {
        name: '김희선',
        descrpition:'아름다운 사람'
    }
};
// match, location, history 등의 객체 활용
// match의 속성인 params, isExact, url 등의 타입 활용
const Profile = ({match}) => {
    const {username} = match.params;
    const profile = data[username];
    if(!profile) {
        return <div>존재하지 않는 사용자입니다</div>
    }
    return (
        <div>
            <h3>
                {username}({profile.name})
            </h3>
            <p>{profile.descrpition}</p>
        </div>
    );
};

export default Profile;