import React from 'react';
import {Link, Route} from 'react-router-dom';
import Profile from './Profile';

// Profile.js와는 별도로 Profiles.js 파일을 서브 라우트 활용하기 위해 만들어 줍니다
const Profiles = () => {
    return (
        <div>
            <h3>사용자 목록:</h3>
            <ul>
                <li>
                    <Link to="/profiles/star">star</Link>
                </li>
                <li>
                    <Link to="/profiles/middle">middle</Link>
                </li>
            </ul>

            <Route
            path="/profiles"
            //exact={ture} 대신 exact라고 축약 표현도 가능함
            exact
            render={() => <div>사용자를 선택해주세요</div>}
            />
            <Route path="/profiles/:username" component={Profile} />
        </div>
    );
};

export default Profiles;