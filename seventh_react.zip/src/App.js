import React from 'react';
import ReactTemplate from './components/ReactTemplate';
import ReactInsert from './components/ReactInsert';

const App = () => {
  return (
    <ReactTemplate>
        <ReactInsert />
    </ReactTemplate>
  );
};

export default App;