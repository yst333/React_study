
// react-icons는 리액트에서 다양하고 예쁜 아이콘을 사용할 수 있는
// 라이브러리입니다. 아이콘 리스트와 사용법은
// https://react-icons.netlify..com/ 에서 확인할 수 있습니다.
// 이 라이브러리의 장점은 SVG 형태로 이루어진 아이콘을
// 리액트 컴포넌트 처럼 매우 쉽게 사용할 수 있다는 점입니다.
// 아이콘의 크기나 색상은 props 혹은 CSS 스타일로 변경이 가능합니다.
// C:\reactstart\css_example>yarn add react-icons 설치해 줍니다.
// C:\react_study\seventh_react>npm install react-icons

// https://react-icons.github.io/react-icons/icons?name=md
// 웹사이트에서 사용하고 싶은 아이콘을 고른 다음,
// import 구문을 사용하여 불러온 후 컴포넌트 처럼 사용하시면 됩니다.
// import {아이콘 이름} from 'react-icons/md';
import React from 'react';
import { MdAdd } from "react-icons/md";
import '../css/ReactInsert.css';

const ReactInsert = () => {
    return (
        <form className='ReactInsert'>
            <input placeholder='할 일을 입력해 주세요' />
            <button type='submit'> 
                <MdAdd />
            </button>
        </form>
    );
};

export default ReactInsert;