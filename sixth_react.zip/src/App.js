import React from 'react';
import Info from './Info';


const App = () => {
  return (
    <div>
      <Info />
    </div>
  );
};

export default App;