/* JSX는 JavaScript XML의 줄임말로 '자바스크립트에 XML을 추가한 확장형 문법'입니다.

XML(eXtensible Markup Language) 또한 HTML(Hyper Text Markup Language)의 표현법을 확장한 문법이므로
자바스크립트와 HTML을 안다면 JSX도 쉽게 이해할 수 있습니다. 또한 기존의 자바스크립트와 HTML을 분리하여
작성하던 번거로운 방식과 달리 JSX는 하나의 파일에 자바스크립트와 HTML을 동시에 작성할 수 있어서 편리합니다. */

import React, { Component } from 'react';

class App extends Component {
  render() {
    // render() 함수 내에 HTML을 사용했다는 점을 알 수 있으며, img 엘리먼트에 />와 같은 표현이 보이는데요. 이것이 JSX 입니다.
    // render() 함수의 반환값(return)은 HTML과 거의 비슷해 보이지만, img 엘리먼트 끝에 마침 표시 />가 있다는 차이점이 있습니다
    // JSX는 HTML이 아니라 XML 마크업 규칙을 따르기 때문에 엘리먼트의 시작 표시 <와 마침 표시 />의 짝이 맞지 않으면 리액트 엔진이
    // JSX를 분석할 때 오류가 발생할 수 있습니다.
    return (
      <div>
        <img src='https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=https%3A%2F%2Fk.kakaocdn.net%2Fdn%2FlyPjw%2FbtqDUFR9PZj%2FOxXyiy69Or1QfIxmvqo7A1%2Fimg.jpg' alt='이미지' />
        <div>안녕하세요!</div>
      </div>
    );
  }
}

export default App;