// 앞서 03폴더에 있는 StateExample.jsx 내용을 App 컴포넌트에 넣어 render() 함수로 화면에 그려보겠습니다.
// 4초 뒤에 state에 저장된 값이 바뀌며 화면에 반영됩니다.
// 즉, 결과를 보면 화면이 4초 뒤에 바뀝니다. 프로퍼티에서 단순히 값을 읽어 화면에 출력한 것과 비교해 보면
// state의 유용함을 경험할 수 있습니다. 다만, 다음의 3가지 state 사용 주의 사항을 체크해야 합니다.
// 1. 생성자(constructor)에서 반드시 초기화해야 합니다.
// 2. state값을 변경할 때는 setState()함수(상태 관리 함수)를 반드시 사용해야 합니다.
// 3. setState() 함수는 비동기로 처리되며, setState()코드 이후로 연결된 함수들의 실행이 완료된 시점에
//    화면 동기화 과정을 거칩니다.
// state에 저장되는 객체는 반드시 초기화해야 합니다. 그렇지 않으면 내부 함수에서 state값에 접근할 수 없습니다.
// 만약 마땅한 초깃값이 없다면 state에 빈 객체라도 넣어야 합니다(this.state={ };)
// 그리고, state에 저장되는 객체의 값은 직접 변경하면 안됩니다.

import React, { Component } from 'react';
import StateExample from './03/StateExample';

class App extends Component {
  render() {
    return (      
      <div>
        <StateExample />
      </div>
    );
  }
}

export default App;