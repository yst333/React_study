// 다음은 ListExample 컴포넌트의 가격표 목록을 출력하는 예제입니다.
// 배열 컴포넌트를 위한 map()함수의 활용 방법을 잘 알아두시기 바랍니다.
// 출력 결과는 App 컴포넌트에 ListExamlpe 컴포넌트를 import 하여 확인합니다.

import React, { Component } from 'react';
import ListExample from './03/ListExample';

class App extends Component {  
  render() {
    return (      
      <div className='body'>
        <ListExample />        
      </div>
    );
  }
}

export default App;