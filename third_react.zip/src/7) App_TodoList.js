import React, { Component } from 'react';
import TodoList from './03/TodoList';

class App extends Component {  
  render() {
    return (
      // render()함수는 데이터가 변경되어 새 화면을 그려야 할 때 자동으로 호출되는 함수입니다.
      // render()함수가 return 반환하는 JSX를 화면에 그려줍니다.
      // 아래의 내용이 JSX 양식 입니다.
      // 아울러, TodoList 컴포넌트를 JSX 안에 마크업 형식으로 추가했습니다.      
      <div className='body'>
        <TodoList />        
      </div>
    );
  }
}

export default App;